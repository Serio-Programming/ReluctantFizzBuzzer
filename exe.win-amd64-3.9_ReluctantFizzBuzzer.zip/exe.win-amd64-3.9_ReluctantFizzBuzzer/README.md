>WHAT IS IT?
This program is a fizzbuzzer.

>WHAT DOES IT DO?
This program counts from 1 up to 100, saying "fizz" when it encounters a number divisable by 3, "buzz" when it encounters a number divisable by 5, and "fizzbuzz" when it encounters a number divisable by both. It also complains.

>HOW DOES IT DO IT?
The program checks to see if the current number being counted leaves an integer after being divided by 3 and 5.

>HOW DO I USE IT?
Simply start the program and it will begin counting/complaining.

>WHAT FILES ARE INCLUDED?
The executable version of this program comes with Python library files and a file containing a list of complaints for the program to access.

>CAMEL:
                  ,,__
        ..  ..   / o._)                   .---.
       /--'/--\  \-'||        .----.    .'     '.
      /        \_/ / |      .'      '..'         '-.
    .'\  \__\  __.'.'     .'          i-._
      )\ |  )\ |      _.'
     // \\ // \\
    ||_  \\|_  \\_
mrf '--' '--'' '--'